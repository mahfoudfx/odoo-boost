============
Saudi Arabia
============

.. |WPS| replace:: :abbr:`WPS (Wages Protection System)`
.. |GOSI| replace:: :abbr:`GOSI (General Organization for Social Insurance)`
.. |MHRSD| replace:: :abbr:`MHRSD (Ministry of Human Resources and Social Development)`
.. |MoL| replace:: :abbr:`MoL (Ministry of Labor)`
.. |EOS| replace:: :abbr:`EOS (End of Service Benefit)`

The Saudi Arabia payroll localization covers salary computations for employees, including national
and provincial regulations.

Before configuring the Saudi Arabia localization, refer to the general :doc:`payroll
<../../payroll>` documentation, which includes the basic information for all localizations, as well
as all universal settings and fields.

.. _payroll/saudi_apps:

Apps & modules
==============

:ref:`Install <general/install>` the following modules to get all the features of the Saudi Arabia
payroll localization:

.. list-table::
   :header-rows: 1

   * - Name
     - Technical name
     - Dependencies
     - Description
   * - :guilabel:`Saudi Arabia - Payroll`
     - `l10n_sa_hr_payroll`
     - - hr_payroll
       - hr_contract_reports
       - hr_work_entry_holidays
       - hr_payroll_holidays
     - Provides Saudi Arabia payroll basics, including salary structures (Basic/Gross/Net).
   * - :guilabel:`Saudi Arabia - Payroll with Accounting`
     - `l10n_sa_hr_payroll_account`
     - - hr_payroll_account
       - l10n_sa
       - l10n_sa_hr_payroll
     - Links payroll and accounting by creating journal entries (per payslip if needed) to record
       payroll in the company's books.

.. seealso::
   :doc:`Configure the Saudi Arabia fiscal localization
   <../../../finance/fiscal_localizations/saudi_arabia>`

General configurations
======================

First, the company must be configured. Navigate to :menuselection:`Settings app --> Users &
Companies --> Companies`. From the list, select the desired company, and configure the following
fields:

- :guilabel:`Company Name`: Enter the business name in this field.
- :guilabel:`Address`: Complete the full address, including the :guilabel:`City`, :guilabel:`State`,
  :guilabel:`Zip Code`, and :guilabel:`Country`.
- :guilabel:`VAT Number`: Enter the company's unique 15-digit :abbr:`VAT (Value Added Tax)` number.
- :guilabel:`Company ID` : Enter the business's MoL number.
- :guilabel:`Currency`: By default, :abbr:`SAR (Saudi riyal)` is selected. If not, select
  :guilabel:`SAR` from the drop-down menu.
- :guilabel:`Phone`: Enter the company phone number.
- :guilabel:`Email`: Enter the email used for general contact information.

Employees
=========

Every employee being paid must have their employee profiles configured for the Saudi Arabia payroll
localization. Additional fields are present after configuring the database for Saudi Arabia.

To update an employee form, open the :menuselection:`Employees` app and click on the desired
employee record. On the employee form, configure the required fields in the related tabs.

Work tab
--------

Enter the :guilabel:`Work Address` for the employee in the :guilabel:`Location` section of the
:guilabel:`Work` tab.

Personal tab
------------

Select the correct :guilabel:`Nationality (Country)` for the employee, using the drop-down menu. The
selected nationality determines the GOSI rate.

Ensure the employee has a minimum of one :ref:`trusted bank account <employees/private-contact>`
listed in the :guilabel:`Bank Accounts` field in the :guilabel:`Private Contact` section.

The employee's *bank account* is their :abbr:`IBAN (International Bank Account Number)`, which is
how employees receive their salary according to :abbr:`WPS (Wages Protection System)` regulations.

Payroll **cannot** be processed for employees without a *trusted* :ref:`bank account
<employees/private-contact>`. If no trusted bank account is set, a warning appears on the
**Payroll** dashboard and an error occurs when attempting to run payroll.

.. image:: saudi_arabia/bank-sa.png
   :alt: Where bank account information is located on the employee profile.

Payroll tab
-----------

Contract overview section
~~~~~~~~~~~~~~~~~~~~~~~~~

This section holds information that drives salary calculations. Ensure the following fields are
configured:

- :guilabel:`Contract`: The Validity of the compensation conditions can be updated depending on the
  needs.
- :guilabel:`Wage Type`: Select how the employee is paid.

  - Select :guilabel:`Fixed Wage` for salaried employees who receive the same amount each pay
    period.
  - Select :guilabel:`Hourly Wage` for employees paid based on hours worked.

  .. tip::
     Set a default :guilabel:`Wage Type` in the salary :ref:`Structure Type
     <payroll/structure-types>` to configure employees in bulk. If needed, the default can be
     overridden on individual employee records if exceptions are needed.

- :guilabel:`Contract Type`: Determines how the employee is paid and classified, such as
  :guilabel:`Permanent`, :guilabel:`Temporary`, :guilabel:`Seasonal`.
- :guilabel:`Pay Category`: Select :abbr:`KSA (Kingdom of Saudi Arabia)` :guilabel:`Employee` for
  this field. This defines when the employee is paid, their default working schedule, and the work
  entry type it applies to.

.. image:: saudi_arabia/payroll-overview-sa.png
   :alt: The contract overview section of the employee form of the payroll tab.

Schedule section
~~~~~~~~~~~~~~~~

- :guilabel:`Work Entry Source`: Defines how :doc:`work entries <../work_entries>` are generated for
  payroll during the specified pay period. The options are:

  - :guilabel:`Working Schedule`: Based on the employee's assigned :ref:`working schedule
    <employees/schedule>` (e.g., 40 hours per week).
  - :guilabel:`Attendances`: Based on :doc:`approved checked-in hours
    <../../attendances/management>` in the **Attendances** app.
  - :guilabel:`Planning`: Based on :ref:`scheduled shifts <planning/shifts>` in the **Planning**
    app.

- :guilabel:`Extra Hours`: Tick the checkbox to allow the **Attendances** app to add any extra work
  entries logged by the employee.
- :guilabel:`Working Hours`: Using the drop-down menu, select the default work schedule. This is
  particularly important for employees available to receive overtime pay (typically hourly
  employees, not salaried).

.. _payroll/saudi_payroll_info:

Saudi payroll information section
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Enter the employee's unique 10-digit :guilabel:`Saudi National / IQAMA ID` number in this field.
This number is issued to Saudi citizens by the :guilabel:`Ministerial Agency of Civil Affairs`, and
is used for exporting WPS reports.

The :guilabel:`Annual Leave Balance` field is not editable, and displays the employee's available
annual vacation days.

Allowances section
~~~~~~~~~~~~~~~~~~

This section determines the various benefits the employee receives. Enter the monthly Saudi riyal
amount the employee receives from the company for :guilabel:`Housing`, :guilabel:`Transportation`,
and :guilabel:`Other` costs.

Enter the annual amount paid by the company for a Saudi :guilabel:`Iqama` (`iqama` is the Arabic
word for `residence permit`). An :guilabel:`Iqama` is an official residency and identification card,
similar to a visa, and it is . It is required for **all** foreign nationals to have a valid
:guilabel:`Iqama` to work, live, and access various services in Saudi Arabia.

Enter the annual amount the employer pays for the employee's :guilabel:`Medical Insurance` in the
corresponding field.

If the employee needs a :guilabel:`Work Permit`, enter the annual fees the company pays.

End of service provision section
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

In Saudi Arabia, each employee earns a percentage of their annual salary for each year they have
worked with a company. This amount is computed based on their salary. When they leave the company,
they receive this compensation in one lump sum.

Enter the :guilabel:`Number of Days` the employee earns in annual compensation, in the corresponding
field. The company sets this amount aside every year, so it is available when the employee leaves.

Payroll configuration
=====================

Several sections within the **Payroll** app installs a Salary Structure, Structure Type, Rules, and
Parameters specific to Saudi Arabia. Additionally, some other configurations are required to run
Saudi Arabia payroll.

.. _payroll/saudi_payroll_settings:

Payroll settings
----------------

Navigate to :menuselection:`Payroll --> Configuration --> Settings` to access the **Payroll** app
settings required for Saudi Arabia.

First, the company bank account must be configured to pay employees, per WPS regulations. Click into
the drop-down space beneath the :guilabel:`Establishment Bank Account` field, and click
:guilabel:`Create...`. This opens a :guilabel:`Create Establishment's Bank Account` pop-up window.
:ref:`Configure the company's bank account  <employees/private-contact>`, and ensure it is marked as
*trusted*. Click :guilabel:`Save` to save the information and close the window.

Next, enter the company's :guilabel:`MoL Establishment ID`. This ID number is provided by Saudi
Arabia's Ministry of Labor.

Finally, select the :doc:`time off type <../../time_off/time_off_types>` that is used to calculate
Finally, select the :doc:`time off type <../../time_off/time_off_types>` that is used to calculate
the :guilabel:`Annual Leave Balance` set in the :ref:`employee's profile
<payroll/saudi_payroll_info>`.

Salary structures & structure types
-----------------------------------

When the **l10n_sa_hr_payroll** module is :ref:`installed <payroll/saudi_apps>`, a new
:guilabel:`Salary Structure` gets installed, :guilabel:`KSA Employee`. This structure includes two
:guilabel:`Structure Types`, :guilabel:`Saudi Arabia: Monthly Pay`, and :guilabel:`SA Salary Advance
And Loan Structure`.

The :guilabel:`Salary Structure` contains all the individual :ref:`salary rules <payroll/usa_apps>`
that informs the **Payroll** app how to calculate employee payslips.

.. image:: saudi_arabia/structure-types-sa.png
   :alt: The Saudi Arabia salary structure in the salary structures list.

.. _payroll/saudi_rules:

Salary rules
------------

To view the salary rules that inform the salary structure what to do, navigate to
:menuselection:`Payroll app --> Configuration --> Structures` and expand the :guilabel:`KSA
Employee` group to reveal the two available structure types. Click :guilabel:`Saudi Arabia: Monthly
Pay` to view the detailed salary rules for that structure type.

.. image:: saudi_arabia/sa-rules-top-half.png
   :alt: The top portion of the US salary rules.

Each rule defines how pay is calculated, taking into account factors such as allowances, deductions,
and company contributions.

Rule parameters
---------------

Some calculations require specific rates associated with them, or wage caps. *Rules Parameters* are
capable of listing a value, either a percentage or a fixed amount, to reference in the salary rules.

Most rules pull information stored in the parameters module to get the rate of the rule (a
percentage) and the cap (a dollar amount).

To view rule parameters, navigate to :menuselection:`Payroll app --> Configuration --> Rule
Parameters`. Here, all rule parameters are displayed with their linked :guilabel:`Salary Rules`,
which can be accessed. Review the parameters associated with a rule by looking for the
:guilabel:`Name` of the rule, and make any edits as needed.

The Saudi Arabia payroll localization comes with four rule parameters:

- :guilabel:`Saudi GOSI Company Contribution`: This rule parameter determines the calculation of the
  GOSI contributions the employer must make for Saudi Arabia employees.
- :guilabel:`Non-Saudi GOSI Company Contribution`: This rule parameter determines the calculation of
  the GOSI contributions the employer must make for each non-Saudi Arabian employee.
- :guilabel:`Saudi GOSI Employee Contribution`: This rule parameter determines the calculation of
  the GOSI contributions the employee must make, and is deducted from their pay.
- :guilabel:`Saudi Arabia Overtime Rate`:  This rule parameter determines the overtime rate for
  employees.

.. important::
   Odoo adds updated rule parameters for the current calendar year. It is **not** recommended to
   edit rule parameters **unless a national or provincial parameter has changed**, and is different
   from the rule parameters created by Odoo. Check with all local and national regulations *before*
   making any changes to rule parameters.

.. _payroll/saudi_run_payroll:

Run Saudi Arabia payroll
========================

Before running payroll, the payroll officer must validate employee :doc:`work entries
<../work_entries>` to confirm pay accuracy and catch errors. This includes checking that all time
off is approved and any overtime is appropriate.

Work entries sync based on the employee's :doc:`contract <../contracts>` configuration. Odoo pulls
from the assigned working schedule, attendance records, planning schedule, and approved time off.

Any :ref:`discrepancies or conflicts <payroll/conflicts>` must be resolved, then the work entries
can be :ref:`regenerated <payroll/regenerate-work-entries>`.

Once everything is correct, draft payslips can be :ref:`created individually
<payroll/payslips/process>` or in :doc:`groups <../pay_runs>`, referred to in the **Payroll** app as
*Pay Runs*.

.. image:: saudi_arabia/work-entries-sa.png
   :alt: The work entries for a pay run, with some time off entered in the work entries.

.. note::
   To cut down on the payroll officer's time, it is typical to process payslips in batches, either
   by wage type (fixed salary vs hourly), pay schedule (weekly, bi-weekly, monthly, etc.),
   department (direct cost vs. administration), or any other grouping that best suits the company.

The process of running payroll includes different actions that need to be executed to ensure that
the amount that the employee receives as their net salary is correct, any deductions or allocations
are correct, and the computation of hours worked reflects the employee's actual hours worked, among
others.

When running a payroll batch, check that the period, company, and employees included are correct
*before* starting to analyze or validate the data.

Once the payslips are drafted, review them for accuracy. Check the :guilabel:`Worked Days & Inputs`
tab, and ensure the listed worked time is correct, as well as any other inputs. Add any missing
inputs, such as commissions, tips, reimbursements, that are missing.

Next, check the various totals (gross pay, allowances, contributions, etc.), then click
:guilabel:`Compute Sheet` to update the salary calculations, if there were edits. If everything is
correct, click :guilabel:`Validate`.

.. image:: saudi_arabia/check-payslips-sa.png
   :alt: The worked days tab of a payslip.

Annual leave provision calculation
----------------------------------

Annual leave provisions are used for calculating the annual leave provision accumulated each month.
It does not affect the total amount paid to the employee, it is for internal use by the company.

It is calculated by dividing the employee's monthly salary (Monthly Salary = Wage + Allowances) by
30 to get the daily salary.

The monthly provision is then calculated as:

.. math::
   :class: overflow-scroll

   \text{Monthly Provision} = \left(\text{Daily Salary} \times \text{Eligible Leave Days}\right) \div 12

When the employee takes a leave, the payout for that leave is taken from the already provisioned
amount and a payout line is automatically calculated and added in the payslip lines.

Employer other costs
--------------------

Other than the employee's salary, there are additional employer costs that need to be accounted for.
These include medical insurance, work permits, and employee's Iqama.

These costs are defined as yearly values on the employee's record under the *Payroll* tab, and are
recognized on a monthly basis as other employer expenses. They are computed on the employee's
payslip, but do not affect the net payable to the employee and do not appear on the payslip PDF
shared with the employee.

Employee net cost
-----------------

To allow payroll officers to track the total employee cost beyond the employee's net salary, the
employee's net cost is computed automatically upon each generated payslip and includes both direct
and indirect costs. Direct costs represent the employee's payable amount, while indirect costs
include other employer costs, as well as contributions such as |GOSI|.

Although these amounts are calculated and available in the system for internal reporting and
analysis, they do not appear on the payslip PDF generated for the employee.

.. example::
   If an employee has a net payable salary of 10,500 SAR and the following indirect costs:

   - Medical insurance of 20,000 SAR a year (1,666.67 SAR a month).
   - GOSI company contribution of 1,057.5 SAR.

   The net cost is: 10,500 + 1,666.67 + 1,057.5  =  13,224.17 SAR

Accounting check
----------------

The accounting process when running payroll has two components: :ref:`creating journal entries
<payroll/journal_saudi>`, and :ref:`registering payments <payroll/register_saudi>`.

.. _payroll/journal_saudi:

Journal entry creation
~~~~~~~~~~~~~~~~~~~~~~

After payslips are confirmed and validated, journal entries are posted either individually, or in a
batch. The journal entry is created first as a draft.

.. important::
   It must be decided if journal entries are done individually or in batches *before* running
   payroll.

.. image:: saudi_arabia/draft.png
   :alt: All payslips in a draft state.

Fifteen accounts from the Saudi Arabia :abbr:`CoA (Chart of Accounts)` are included with the payroll
localization:

- `400003 Basic Salary`: Tracks the basic wages paid to employees.
- `400004 Housing Allowance`: Captures housing allowance payments provided to employees.
- `400005 Transportation Allowance`: Captures transportation allowance payments to employees.
- `400012 Staff Other Allowances`: Covers employee allowances that do not fit standard categories.
- `106012 Prepaid Employee Expenses`: Logged as prepaid assets for employer-paid items that are
  *not* wages (for example, `Iqama` fees and medical insurance) and expensed as consumed.
- `201006 Leave Days Provision`: Accrues the cost of paid leave; the balance is reduced when leave
  is taken, and any leave not taken may be paid out at end of service.
- `201022 GOSI Employee Payable`: Holds amounts payable for social insurance contributions to the
  GOSI, including both employee and employer portions.
- `202001 End of Service Provision`: Accumulates the end-of-service benefit monthly so the amount
  can be paid (partially or fully) when the employee leaves, per service length and reason.
- `400007 Leave Salary`: Records salaries actually paid to employees while on paid leave.
- `400008 End of Service Indemnity`: Captures company expenses set aside to fund end-of-service
  benefits (expense-side counterpart to the provision).
- `400009 Medical Insurance`: Accounts for employer expenses related to employee medical insurance
  premiums.
- `400010 Life Insurance`: Tracks employer expenses for life/occupational insurance or the
  employer's portion of social insurance.
- `400014 Visa Expenses`: Used to track employer costs for non-Saudi Arabian employees' visas and
  related processing/renewal fees.
- `400074 Salary Deductions`: Reflects deductions applied to employee salaries (e.g., advances,
  fines, statutory deductions).
- `201002 Payables`: Shows amounts payable to employees as salaries (unpaid salary liability at
  period end).

If everything seems correct on the journal entry draft, post the journal entries.

.. image:: saudi_arabia/validated.png
   :alt: Journal entries posted.

.. _payroll/register_saudi:

Register Payments
-----------------

After the :ref:`journal entries <payroll/journal_saudi>` are validated, Odoo can generate payments.

.. important::
   To generate payments from payslips,employees **must** have a *trusted* bank account. If the
   employee's bank account is *not* marked as `trusted`, WPS files **cannot** be generated through
   Odoo.

Payments can be :guilabel:`Grouped by Partner` if there is a partner associated with a salary rule.

.. image:: saudi_arabia/paid.png
   :alt: Payslips with a status of paid.

Close payroll
-------------

If there are no errors, payroll is completed for the pay period.

Sick leaves
===========

Sick leave rules define how the employee's payslip is affected when the employee takes sick leave.

There are three sick leave cases:

- Fully paid sick leave: Employees are entitled to 30 days per calendar year.
- 75% paid sick leave: Employees are entitled to 60 additional days after the first 30 fully paid
  sick leave days.
- Unpaid sick leave: Any sick leave beyond the first 90 days is considered unpaid.

.. important::
   The sick leave entitlement limits mentioned above are calculated within a one-year period. This
   period starts from the date of the employee's first sick leave, and any subsequent sick leave
   taken during that period is counted toward the employee's entitlement.

The sick leave compensation is calculated using the following formula, where the gross monthly
salary is the employee's basic salary plus all allowances defined on the employee's contract:

.. math::
   :class: overflow-scroll

   \text{Sick Leave Amount} = \left(\frac{\text{Gross Monthly Salary}}{30}\right) \times \text{Number of Sick Leave Days} \times \text{Percentage}

.. note::
   There is a single sick leave time off type, *Sick Time Off*. The system automatically tracks the
   total number of sick leave days taken by the employee and applies the corresponding percentage
   based on the accumulated balance.

End of employee collaboration
=============================

At the end of an employee's service with the company, they may be entitled to an *End of Service
Benefit* (EOS) depending on:

- The duration of their service.
- The reason for the termination of the employment relationship.

The reason for the termination can fall under one of the following categories:

End of contract / retirement
----------------------------

If the employee's service duration is between one and five years, the employee is entitled to half
of their latest monthly salary for each year of service.

For each year beyond the fifth year, the employee is entitled to one full monthly salary per year.

Resignation
-----------

If the employee resigns after completing between two and five years of service, they are entitled to
one third of the |EOS| amount that would normally be granted in the case of an *End of Contract*.

.. example::
   If an employee worked for three years and resigned, the |EOS| is first computed as if the
   termination reason was *End of Contract*, then the employee receives one third of that amount.

Fired
-----

If the employee is dismissed, they are not entitled to an |EOS| regardless of their service
duration.

Termination Without a valid legal reason
----------------------------------------

As defined under Article 77 of the Saudi Labor Law, if the employment contract does not define a
compensation amount for unlawful termination by either party, the affected party is entitled to
compensation as follows:

- For indefinite-term contracts, the compensation is equal to half of the employee's monthly salary
  for each year of service.
- For fixed-term contracts, the compensation is equal to the employee's wage for the remaining
  contract duration.

In addition to the |EOS|, the employee is also entitled to receive compensation for any unused
annual leave balance.

The unused leave compensation is computed by multiplying the employees daily wage by the number of
remaining unused days from the *Annual Leave* time off type.

An |EOS| provision must also be recognized to account for the future liability payable to the
employee at the end of their service with the company. Unlike the |EOS| benefit itself, the
provision is accrued progressively and is included in the employee's payslips from the start of
their contract.

Similar to the |EOS| benefit, the provision is calculated differently depending on the employee's
length of service:

- For employees with less than 5 years of service: (Monthly wage / 12) × 0.5
- For employees with more than 5 years of service: (Monthly wage / 12)

The provision is always computed using the scenario that results in the highest expected expense,
which is when the reason is `End of Contract`.

In cases where the actual termination reason results in a lower entitlement, an adjustment line is
automatically added on the payslip lines to account for the difference between the provisioned
amount and the actual amount due.

Advanced leave pay
==================

Employees can request an advance payment of their salary when going on paid leave, especially when
the leave spans multiple months.

The advance payslip includes the employee's salary for the days worked in the current month, and the
salary for the leave period. When the leave extends beyond the current month, the system
automatically calculates the additional days needed to be compensated and adds them as extra inputs
on the payslip.

In the following month, any amount already paid in advance is automatically deducted from the
employee's salary through a salary input line to avoid double payment.

To generate an advance leave payslip, go to the approved employee's time off request for the time
off type `Annual Leave`, then click :guilabel:`Create Advance Leave Pay`.

Employee loans and advances
===========================

Employees are able to request :ref:`loans <payroll/loans>` or :ref:`advances <payroll/advances>`
against their salaries. *Loans* are handled by creating salary adjustments, whereas *advances* are
created and managed manually.

.. _payroll/loans:

Employee loans
--------------

Employees can take out *loans* against their salary and repay the loan with automatic deductions
from future paychecks. These loans are handled by :ref:`creating a salary adjustment
<payroll/salary_adjust_saudi>` to log the total loan amount and set up a repayment plan, and
:ref:`creating a payslip for the total loan amount <payroll/loan_payslip_saudi>`. The employee then
:ref:`repays the loan <payroll/repay_saudi>` in the increments configured in the salary adjustment.

.. _payroll/salary_adjust_saudi:

Create a salary adjustment
~~~~~~~~~~~~~~~~~~~~~~~~~~

When an employee requests a loan, first a *salary adjustment* is made, where the total loan amount
and repayment plan is configured.

To create the loan and repayment schedule, navigate to :menuselection:`Payroll app --> Employees -->
Salary Adjustments`. Click :guilabel:`New`, and a blank :guilabel:`Salary Adjustment` form loads.

Configure the following fields on the form:

- :guilabel:`Employees`: Using the drop-down menu, select the employee taking out the loan.
- :guilabel:`Type`: Using the drop-down menu, select :guilabel:`Loan Deduction`.
- :guilabel:`Payslip Amount`: Enter the :abbr:`SAR (Saudi riyal)` amount to be repaid each payslip.
- :guilabel:`Duration`: Tick the :guilabel:`Limited` option, which reveals a :guilabel:`until`
  (amount) :guilabel:`paid` field. First, using the calendar selector, enter the date the repayment
  begins. Next, enter the total loan amount in the field after :guilabel:`until`. Once both fields
  are configured, Odoo calculates when the loan is fully repaid, and displays the date as follows:
  `end in # years: (date)`.
- :guilabel:`Note`: Enter any details about the loan in this field.

.. image:: saudi_arabia/loan.png
   :alt: A salary adjustment form filled out for an employee loan.

.. _payroll/loan_payslip_saudi:

Generate a loan payslip
~~~~~~~~~~~~~~~~~~~~~~~

After creating the salary adjustment, a button labeled :guilabel:`Create Loan Payslip` appears above
the form. Click :guilabel:`Create Loan Payslip`, and Odoo automatically generates a payslip
configured for the employee loan, in the amount set up in the :ref:`salary adjustment
<payroll/salary_adjust_saudi>`.

Review the payslip to ensure all the fields and tabs are correct. The :guilabel:`Structure` should
be :guilabel:`SA Salary Advance And Loan Structure`. The :guilabel:`Salary Inputs` tab should list a
:guilabel:`Loan Deduction`, and the :guilabel:`Total` should be the full amount of the loan.

Click into the :guilabel:`Other Info` tab, and enter the date the employee receives the payment in
the :guilabel:`Payment Date` field.

Once the payslip form is correct, click :guilabel:`Compute Sheet`, then click :guilabel:`Create
Draft Entry`, and click :guilabel:`OK` in the confirmation pop-up window. Next, click
:guilabel:`Pay` to mark the payment as paid, then click :guilabel:`Create Payment Report` to
:ref:`generate the WPS report <payroll/reports_saudi>`.

.. image:: saudi_arabia/loan-payslip.png
   :alt: A configured loan payslip.

.. _payroll/repay_saudi:

Loan repayment to employer
~~~~~~~~~~~~~~~~~~~~~~~~~~

From the date set on the :ref:`salary attachment <payroll/salary_adjust_saudi>`, all future
paychecks have the configured repayment amount taken out, to go towards the loan. Once the loan is
fully paid, the deductions end.

.. note::
   The deductions should end after the total is repaid, according to the salary adjustment. To
   ensure payments *stop* being taken out of the employee's paychecks after the loan has been
   repaid, open the salary adjustment record. If the salary adjustment still has a status of
   :guilabel:`Running`, click the :guilabel:`Mark as Completed` button, and the status changes to
   :guilabel:`Closed`, and payments stop.

.. _payroll/advances:

Salary advances
---------------

Employees can request an advance of their salary, outside of the regular pay cycle. This process is
done by paying the employee with a :ref:`manually created payslip <payroll/advance_slip>`, then the
employee repays the advance either :ref:`in full <payroll/repay_full>` in the next payslip, or in
:ref:`multiple payments <payroll/repay_partial>` in subsequent paychecks until the total is repaid.

.. _payroll/advance_slip:

Create advance payslip
~~~~~~~~~~~~~~~~~~~~~~

To issue an advanced payment, navigate to :menuselection:`Payroll app --> Payslips --> Payslips`.
Click the :guilabel:`New Off-Cycle` button and a blank :guilabel:`Employee Payslips` form loads.

Configure the following fields on the payslip:

- :guilabel:`Employees`: Using the drop-down menu, select the employee taking out the advance.

  .. note::
     Once the :guilabel:`Employee` is selected, the :guilabel:`Employee Record` field populates with
     the most recent employee version (contract).

- :guilabel:`Structure`: Using the drop-down menu, select :guilabel:`SA Salary Advance And Loan
  Structure`.
- :guilabel:`Period`: Set the start and end date for the payslip in the two corresponding fields
  using the calendar selectors.

Next, click into the *Salary Inputs* tab, and in the *Inputs* section, enter the amount being
advanced in the :guilabel:`Salary Advance` field.

Once the payslip is configured, click :guilabel:`Compute Sheet`, then click :guilabel:`Create Draft
Entry`, and click :guilabel:`OK` in the confirmation pop-up window. Click :guilabel:`Pay` to mark
the payment as paid, then click :guilabel:`Create Payment Report` to :ref:`generate the WPS report
<payroll/reports_saudi>`.

.. image:: saudi_arabia/advance.png
   :alt: A configured loan payslip.

.. _payroll/repay_full:

Automatic repayment in full
~~~~~~~~~~~~~~~~~~~~~~~~~~~

When the employee's next payslip is generated (using the `Saudi Arabia: Monthly Pay` structure), a
line is added under the `Other Inputs` tab, titled `Advanced Recovery`.

The amount is based on the advance previously taken by the employee. If the employee cannot repay
the full amount in the paycheck, the repayment can be broken up into :ref:`multiple payments
<payroll/repay_partial>`.

.. _payroll/repay_partial:

Multiple payments
~~~~~~~~~~~~~~~~~

When an employee cannot repay an advance in full in a future payslip, the employee can make partial
payments until the advance is repaid. To do this, the amount being deducted from the employee's
paycheck must be manually modified.

Open the employee's payslip, and under the :guilabel:`Salary Inputs` tab, modify the amount
specified on the :guilabel:`Advanced Recovery` line.

Odoo automatically calculates the remainder of the advance, and adds an :guilabel:`Advanced
Recovery` line for the balance in the subsequent payslip. If the employee cannot pay the second
payment in full, the :guilabel:`Advanced Recovery` line can be edited in the following payslip.

Late attendance tracking
========================

Monitoring late arrivals is an essential aspect of attendance tracking and workforce discipline.
Within the attendance module, this can be handled by setting up the work schedules and check-in
times for each day of the week. When employees check in after their expected start time, the record
will be flagged for the HR responsible for approval, and once approved, it will take effect in the
employee's next salary.

Once the module **Saudi Arabia Payroll - Attendance** is installed, the HR manager needs to set the
grace period from the payroll settings. This grace period defines the amount of time an employee is
allowed to be late without triggering the late attendance rules.

If the grace period is not set or is exceeded, the system tracks how many minutes the employee was
late, and the HR manager's approval will be required to confirm the lateness.

Once confirmed, on the next payslip, the number of late hours is reflected on the payslip under the
*Salary Inputs* tab, and a deduction is applied to the employee according to the following formula:

.. math::
   \frac{\text{Basic Wage} \div 30}{\text{Number of hours per day}} \times\text{Number of late hours}

.. note::
   If the employee is late for more than the grace period duration, then the grace period duration
   itself will be considered as a part of the late time.

GOSI Integration
================

The General Organization for Social Insurance (GOSI) is the government entity in Saudi Arabia
responsible for implementing the Social Insurance Law, collecting contributions from employers, and
providing insurance coverage and benefits to eligible contributors and their families.

The insurance system is composed of three main branches: the Annuities Branch, the Occupational
Hazards Branch, and the Unemployment Insurance (SANED) Branch.

The integration with |GOSI| enables the automatic retrieval of contribution percentages for all
three branches for both employees and employers. These percentages are then used to compute social
insurance contributions in employees' payslips, ensuring accurate and compliant payroll
calculations.

To set up the integration, navigate to :menuselection:`Payroll --> Configuration --> Settings`.
Under the *GOSI Integration* section, configure the following fields according to the information
obtained from the |GOSI| portal:

- Registration Number
- API Key
- Client ID
- Client Secret
- DPoP Key
- API Mode

.. important::
   The DPoP must strictly follow the exact format provided by |GOSI|. Any missing space or character
   will result in an error. After all details are filled in and saved, the :guilabel:`Test
   Connection` button becomes available. Clicking it validates the provided credentials. Once the
   integration is successful, ensure that the employee's Iqama number is correctly set on the
   employee profile under the *Payroll* tab. When properly configured, the contribution percentages
   are retrieved for each insurance branch. On the employee payslip, two salary rules are used to
   calculate the total contributions for both the employee and the employer across all three
   insurance branches.

.. note::
   Although both employee and employer contributions are computed on the payslip, only the
   employee's contribution is displayed on the final PDF shared with the employee.

.. _payroll/reports_saudi:

Nationalization % report
========================

Tracking the nationalization percentage is required to comply with the nationalization regulations
set by the Ministry of Human Resources under the Nitaqat program.

The tracking must be done at both company and department level and is based on the minimum wage
defined for each department, which can be configured on the :doc:`department
<../../employees/departments>` record.

The nationalization report can be accessed by navigating to :menuselection:`Employees --> Reporting
--> Nationalization Report`.

The report includes filters such as the department and reference date. Based on these filters, it
displays the resulting nationalization percentage along with a link to the employees that satisfy
those chosen filters.

WPS reports
===========

The WPS report is a mandatory report all Saudi Arabian companies are required to provide the
government. The report confirms employee wages, including when and how much they were paid. The WPS
report can be generated either per payslip or per pay run.

.. note::
   This report is structured in accordance with the technical guidelines issued by the MHRSD.

.. important::
   To run the WPS report, the :guilabel:`Establishment Bank Account` and :guilabel:`Ministry of
   Labor Establishment ID` fields **must** be :ref:`configured <payroll/saudi_payroll_settings>` for
   the company.

   Ensure the :guilabel:`Establishment Bank Account` has the :guilabel:`Bank Establishment ID`,
   and :guilabel:`Bank SARIE Code` fields configured, and the bank is marked as :guilabel:`Trusted`.

   Ensure all employees included in the report have a :guilabel:`Saudi National / IQAMA ID` set on
   their employee profile.

First, :ref:`payslips or pay runs are generated <payroll/saudi_run_payroll>`, then the :ref:`journal
entries are posted <payroll/journal_saudi>`.

Click the :guilabel:`Payment Report` button on the :guilabel:`Pay Runs` dashboard, the individual
pay run, or an individual payslip, and a payment report pop-up window loads.

:guilabel:`Saudi WPS` is selected in the :guilabel:`Export Format` field, by default, and the
:guilabel:`Payment Date` and :guilabel:`WPS Value Date` fields are both populated according to the
selected payslips or pay runs.

The :guilabel:`WPS Debit Date` is an optional field, and specifies the date the company physically
pays the employees (transfers funds from the company account to employee accounts).

Once all fields are configured, click :guilabel:`Generate`, and the WPS report is created.
