================
Reordering rules
================

.. |SO| replace:: :abbr:`SO (Sales Order)`
.. |SOs| replace:: :abbr:`SOs (Sales Orders)`
.. |RFQ| replace:: :abbr:`RFQ (Request for Quotation)`
.. |RFQs| replace:: :abbr:`RFQs (Requests for Quotations)`
.. |PO| replace:: :abbr:`PO (Purchase Order)`
.. |POs| replace:: :abbr:`POs (Purchase Orders)`
.. |MO| replace:: :abbr:`MO (Manufacturing Order)`
.. |MOs| replace:: :abbr:`MOs (Manufacturing Orders)`
.. |BoM| replace:: :abbr:`BoM (Bill of Materials)`
.. |BoMs| replace:: :abbr:`BoMs (Bills of Materials)`
.. |adjust| replace:: :icon:`oi-settings-adjust` :guilabel:`(adjust settings)` icon

*Reordering rules* are used to keep forecasted stock levels above a certain threshold without
exceeding a specified upper limit. This is accomplished by specifying a minimum quantity that stock
should not fall below and a maximum quantity that stock should not exceed.

Reordering rules can be configured for each product based on the route used to replenish it. If a
product uses the *Buy* route, then a *request for quotation* (RFQ) is created when the reordering
rule is triggered. If a product uses the *Manufacture* route, then a *manufacturing order* (MO) is
created instead. This is the case regardless of the selected replenishment route.

.. seealso::
   - `Odoo Tutorials: Reordering Rules <https://www.youtube.com/watch?v=nJ2grHTSOwo>`_

To set up reordering rules for the first time, refer to:

- :ref:`Reordering rules setup <inventory/warehouses_storage/configure-rr>`
- :ref:`Trigger <inventory/warehouses_storage/trigger>`
- :ref:`Preferred route <inventory/warehouses_storage/route>`

To understand and optimize replenishment using advanced features, see:

- :doc:`Just in time logic <just_in_time>`
- :ref:`Horizon days <inventory/warehouses_storage/horizon-days>`

.. _inventory/warehouses_storage/configure-rr:

Reordering rules setup
======================

To configure automatic and manual reordering rules, complete the following:

#. :ref:`Product type configuration <inventory/warehouses_storage/set-product-type>`
#. :ref:`Replenishment method <inventory/warehouses_storage/set-method>`
#. :ref:`Create rule <inventory/warehouses_storage/rr-fields>`

.. _inventory/warehouses_storage/set-product-type:

Product type configuration
--------------------------

A product must be configured correctly to use reordering rules. Begin by navigating to
:menuselection:`Inventory app --> Products --> Products`, then select an existing product, or create
a new one by clicking :guilabel:`New`.

On the product form, under the *General Information* tab, set the :guilabel:`Product Type` to
:guilabel:`Goods`, and make sure the :guilabel:`Track Inventory` checkbox is ticked. This is
necessary for Odoo to track the product's stock levels and trigger reordering rules.

.. image:: reordering_rules/product-type.png
   :alt: Product Type and Track Inventory configurations.

.. _inventory/warehouses_storage/set-method:

Replenishment method
--------------------

Next, configure the replenishment method (e.g. buy or manufacture).

If the product is purchased, :ref:`install <general/install>` the **Purchase** app, and confirm that
the :guilabel:`Purchase` checkbox is enabled under the product name. In the *Purchase* tab, add at
least one vendor to the :doc:`vendor pricelist <../../../purchase/products/pricelist>`. Odoo uses
the vendor at the top of the list to generate |RFQs| when reordering rules are triggered.

.. seealso::
   :doc:`Vendor pricelist <../../../purchase/products/pricelist>`

If the product is manufactured, :ref:`install <general/install>` the **Manufacturing** app.

Next, ensure at least one :doc:`bill of materials
<../../../manufacturing/basic_setup/bill_configuration>` (BoM) is displayed in the :guilabel:`Bill
of Materials` smart button at the top of the product form. This is necessary because Odoo only
creates manufacturing orders (MOs) for products with a |BoM|.

If a |BoM| does not already exist for the product, click the :guilabel:`Bill of Materials` smart
button, then click :guilabel:`New` to configure a new |BoM|.

.. seealso::
   :doc:`Configure BoM <../../../manufacturing/basic_setup/bill_configuration>`

.. _inventory/warehouses_storage/rr-fields:

Create a reordering rule
------------------------

To create a new reordering rule, navigate to :menuselection:`Inventory app --> Operations -->
Replenishment`, then click :guilabel:`New`, and fill out the following fields for the new reordering
rule line item:

- :guilabel:`Product`: The product that is replenished by the rule.
- :guilabel:`Location`: The location where the product is stored.
- :guilabel:`Min`: The minimum quantity that can be forecasted without the rule being triggered.
  When forecasted stock falls below this number, a replenishment order for the product is created.
- :guilabel:`Max`: The maximum quantity at which the stock is replenished.

.. figure:: reordering_rules/reordering-rule-form.png
   :alt: The form for creating a new reordering rule.

   The form for creating a new reordering rule.

.. tip::
   Reordering rules can also be created from the :guilabel:`Reordering Rules` smart button on the
   product form.

.. note::
   To learn how the :guilabel:`On Hand`, :guilabel:`Forecast`, and :guilabel:`To Order` fields are
   calculated using on-hand quantities and future demand, see :doc:`Just in time logic
   <just_in_time>`

For advanced usage, learn about the following reordering rule fields:

- :ref:`Trigger <inventory/warehouses_storage/trigger>`
- :ref:`Preferred route <inventory/warehouses_storage/route>`
- :ref:`Vendor <inventory/warehouses_storage/set-vendor>`
- :ref:`Bill of materials <inventory/warehouses_storage/set-bom-field>`
- :ref:`Multiple <inventory/warehouses_storage/multiple>`

.. note::
   The fields above are not available by default, and must be enabled by selecting the |adjust| in
   the far-right corner and selecting the desired column from the drop-down menu.

.. _inventory/warehouses_storage/zero-zero:

0/0/1 reordering rule
---------------------

The *0/0/1* reordering rule is a specialty rule used to replenish a product that is not kept
on-hand, each time a sales order (SO) is confirmed for that product.

.. important::
   The 0/0/1 reordering rule is similar to the *Replenish on Order (MTO)* route, in that both
   workflows are used to replenish a product upon confirmation of an |SO|.

   The main difference between the two methods is that the *Replenish on Order* route automatically
   reserves the product for the |SO| that caused it to be replenished. This means the product
   **cannot** be used for a different |SO|.

   The 0/0/1 reordering rule does not have this limitation. A product replenished using the rule is
   not reserved for any specific |SO|, and can be used as needed.

   Another key difference is that replenishment orders created by the *Replenish on Order* route are
   linked to the original |SO| by a smart button at the top of the order. When using the 0/0/1
   reordering rule, a replenishment order is created, but is not linked to the original |SO|.

   See the :doc:`Replenish on Order (MTO) <mto>` documentation for a full overview of the MTO route.

To create a 0/0/1 reordering rule, navigate to :menuselection:`Inventory app --> Products -->
Products`, and select a product.

At the top of the product's page, click the :icon:`fa-refresh` :guilabel:`Reordering Rules` smart
button to open the *Reordering Rules* page for the product. On the resulting page, click
:guilabel:`New` to begin configuring a new reordering rule.

In the :guilabel:`Location` field of the new reordering rule, select the location in which
replenished products should be stored. By default, this location is set to :guilabel:`WH/Stock`.

In the :guilabel:`Route` field, select the route the rule should use to replenish the item. For
example, if the product should be purchased from a vendor, select the :guilabel:`Buy` route.

In the :guilabel:`Min` field and :guilabel:`Max` field, leave the values set to `0.00`. In the
:guilabel:`To Order` field, enter a value of `1.00`.

.. image:: reordering_rules/001-rule.png
   :alt: A 0/0/1 reordering rule.

With the reordering rule configured using these values, each time an |SO| causes the forecasted
quantity of the product to fall below the :guilabel:`Min` of `0.00`, the selected :guilabel:`Route`
is used to replenish the product in one-unit increments, back up to the :guilabel:`Max` of `0.00`.

.. example::
   An item is configured with a 0/0/1 reordering rule that uses the *Buy* route. Zero units are kept
   on-hand at any given time.

   A |SO| is confirmed for one unit, which causes the forecasted quantity to drop to `-1.00`. This
   triggers the reordering rule, which automatically creates a |PO| for one unit.

   Once the product is received from the vendor, the forecasted quantity returns to `0.00`. There is
   now one unit on-hand, but it is not reserved for the |SO| which triggered its purchase. It can be
   used to fulfill that |SO|, or reserved for a different order.

.. _inventory/warehouses_storage/multiple:

Multiple
--------

The :guilabel:`Multiple` field on the replenishment report (:menuselection:`Inventory app -->
Operations --> Replenishment`) defines the unit used when replenishing a product. Odoo rounds the
ordered quantity *up* to the nearest multiple that meets or slightly exceeds the :guilabel:`Max`
quantity set on the reordering rule. If no multiples apply, select :guilabel:`Units`.

.. example::
   A vendor sells soda only in cases of six cans, but your company tracks quantities per can.
   Setting the :guilabel:`Multiple` to `6` ensures soda is ordered in multiples of six (6, 12,
   18...).

   For a reordering rule with the :guilabel:`Min` = `10` and :guilabel:`Max` = `40`:

   - If the forecasted quantity is `10`, the amount :guilabel:`To Order` is `30`, a multiple of six
     that will bring the :guilabel:`On Hand` quantity to exactly the maximum.
   - If the forecasted quantity is `8`, the quantity needed to reach the max is `32`. But 32 is not
     a multiple of six, so Odoo rounds the :guilabel:`To Order` quantity up to `36`. This will cause
     the :guilabel:`On Hand` quantity to slightly exceed the maximum.

   .. image:: reordering_rules/multiple.png
      :alt: Reordering rule with the Multiple set to 6.

.. note::
   If the maximum is exceeded, expect to see a :icon:`fa-warning` warning indicating the possibility
   of excessive stock.

Configuration
~~~~~~~~~~~~~

Multiples are based on defined :doc:`packagings <../../product_management/configure/packaging>`.
Only packaging types listed on the product's :doc:`vendor pricelist
<../../../purchase/products/pricelist>` appear as options in the :guilabel:`Multiple` field when
configuring reordering rules.

.. _inventory/warehouses_storage/trigger:

Trigger
=======

A reordering rule's *trigger* can be set to *automatic* or *manual*. While both function the same
way, the difference between the two types of reordering rules is how the rule is launched:

- :ref:`Auto <inventory/warehouses_storage/auto-rr>`: A purchase or manufacturing order is
  automatically created when the forecasted stock falls below the reordering rule's minimum
  quantity. By default, the :guilabel:`Auto` trigger is selected.
- :ref:`Manual <inventory/warehouses_storage/manual-rr>`: The :doc:`Replenishment report <report>`
  lists products needing replenishment, showing current/forecasted stock, lead times, and arrival
  dates. Users can review forecasts before clicking *Order*.

To enable the :guilabel:`Trigger` field, go to :menuselection:`Inventory app --> Operations -->
Replenishment`. Then, click the |adjust|, located to the far-right of the column titles, and tick
the :guilabel:`Trigger` checkbox.

In the :guilabel:`Trigger` column, select :guilabel:`Auto` or :guilabel:`Manual`. Refer to the
sections below to learn about the different types of reordering rules.

.. _inventory/warehouses_storage/auto-rr:

Auto
----

*Automatic reordering rules*, enabled by setting the reordering rule's :guilabel:`Trigger` field to
:guilabel:`Auto`, generate purchase or manufacturing orders when either:

#. The scheduler runs, and the *Forecasted* quantity is below the minimum, or
#. A |SO| is confirmed, and lowers the *Forecasted* quantity of the product below the minimum.

If the :guilabel:`Buy` route is selected, then an |RFQ| is generated. To view and manage |RFQs|,
navigate to :menuselection:`Purchase app --> Orders --> Requests for Quotation`.

If the :guilabel:`Manufacture` route is selected, then an |MO| is generated. To view and manage
|MOs|, navigate to :menuselection:`Manufacturing app --> Operations --> Manufacturing Orders`.

When no route is selected, Odoo selects the :guilabel:`Route` specified in the *Inventory* tab of
the product form.

.. tip::
   The scheduler is set to run once a day, by default.

   To manually trigger a reordering rule before the scheduler runs, ensure :ref:`developer mode
   <developer-mode>` is enabled, and select :menuselection:`Inventory app --> Operations --> Run
   Scheduler`. Then, click the purple :guilabel:`Run Scheduler` button on the pop-up window that
   appears.

   Be aware that this also triggers any other scheduled actions.

.. example::
   The product, `Office Lamp`, has an automatic reordering rule set to trigger when the forecasted
   quantity falls below the :guilabel:`Min Quantity` of `5.00`. Since the current
   :guilabel:`Forecast` is `55.00`, the reordering rule is **not** triggered.

   .. image:: reordering_rules/auto.png
      :alt: Show automatic reordering rule from the Reordering Rule page.

.. _inventory/warehouses_storage/manual-rr:

Manual
------

*Manual reordering rules*, configured by setting the reordering rule's :guilabel:`Trigger` field to
:guilabel:`Manual`, list a product on the :doc:`replenishment dashboard <report>` when the
forecasted quantity falls below a specified minimum. Products on this dashboard are called *needs*,
because they are needed to fulfill upcoming |SOs|, for which the forecasted quantity is not enough.

The replenishment dashboard, accessible by navigating to :menuselection:`Inventory app -->
Operations --> Replenishment`, considers order deadlines, forecasted stock levels, and lead times.
It displays needs **only** when it is time to reorder items, thanks to the :guilabel:`To Reorder`
filter.

When a product appears on the replenishment dashboard, clicking the :guilabel:`Order` button
generates the purchase or manufacturing order with the specified amounts :guilabel:`To Order`.

.. image:: reordering_rules/manual.png
   :alt: Click the Order button on the replenishment dashboard to replenish stock.

.. _inventory/warehouses_storage/route:

Route
=====

Odoo allows for multiple routes to be selected as replenishment methods under the *Inventory* tab on
each product form. For instance, it is possible to select both :guilabel:`Buy` and
:guilabel:`Manufacture`, indicating to Odoo that the product can be bought or manufactured.

.. seealso::
   :ref:`Set route on product form <inventory/warehouses_storage/set-method>`

Odoo also enables users to set a preferred route for a product's reordering rule. This is the
replenishment method (e.g., buying or manufacturing) that the rule defaults to, if multiple are
available.

To specify a preferred route, begin by navigating to :menuselection:`Inventory app --> Operations
--> Replenishment`.

By default, the :guilabel:`Route` column is hidden. To reveal it, select the |adjust| to the
far-right of the column titles, and ticking :guilabel:`Route` from the drop-down menu that appears.

Click inside of the column on the row of a reordering rule, and a drop-down menu shows all available
routes for that rule. Select one to set it as the preferred route.

.. image:: reordering_rules/select-preferred-route.png
   :alt: Select a preferred route from the drop-down.

.. important::
   If multiple routes are enabled for a product but no preferred route is set for its reordering
   rule, the product is reordered using the *Buy* route, then *Manufacture*.

Advanced uses
-------------

Pairing :guilabel:`Route` with one of the following fields on the replenishment report unlocks
advanced configurations of reordering rules. Consider the following:

.. _inventory/warehouses_storage/set-vendor:

- :guilabel:`Vendor`: When the selected :guilabel:`Route` is :guilabel:`Buy`, setting the
  :guilabel:`Vendor` field to one of the multiple vendors on the vendor pricelist indicates to Odoo
  that the vendor is automatically populated on |RFQs| when a reordering rule triggers the creation
  of a purchase order.

.. _inventory/warehouses_storage/set-bom-field:

- :guilabel:`Bill of Materials`: When the :guilabel:`Route` is set to :guilabel:`Manufacture`, and
  there are multiple |BoMs| in use, specifying the desired |BoM| in the replenishment report, draft
  manufacturing orders are created with this |BoM| in use.

.. seealso::
   :doc:`Just-in-time logic <just_in_time>`

Horizon days
============

*Horizon days* allow users to extend the time window between today's date and the forecasted date
when calculating for the forecasted quantity. This features allows users to plan and restock
inventory proactively, rather than following a just-in-time approach. The feature is meant to help
users plan replenishment in advance by increasing the :ref:`forecasted date
<inventory/warehouses_storage/forecasted-date>`.

.. math::
   :class: overflow-scroll

   \text{Forecasted date} = \text{Current date} + \text{Vendor Lead Time} + \text{Horizon Days}

Since horizon days are only meant to be used with manual reordering rules, find details about the
feature in the :doc:`Replenishment report article <report>`.

.. note::
   Horizon days are configured on a company level.

The default horizon days setting can be set or updated by navigating to the
:menuselection:`Inventory app --> Advanced Scheduling`. Enter the desired number of days in the
:guilabel:`Replenishment Horizon` field, and click :guilabel:`Save`.

.. image:: reordering_rules/replenishment-horizon.png
   :alt: The Replenishment Horizon setting in the Inventory app.

Example of how horizon days affect replenishment planning
---------------------------------------------------------

On the Replenishment report, there are currently two products listed due for reordering: `Drawer,
Black` and `Corner Desk`. This is based on their current level of on-hand stock, and their
forecasted stock level. The default horizon days is set as `20`.

.. image:: reordering_rules/twenty-days.png
   :alt: Replenishment report with horizon days set at 20.

However, by extending the horizon days to `30`, an additional product is added to the list.

.. image:: reordering_rules/thirty-days.png
   :alt: Replenishment report with horizon days set at 30.

This is because the additional product, `[FURN_0789] Individual Workplace`, has a delivery scheduled
in twenty-nine days, at which point their on-hand stock levels will fall below the minimum needed
on-hand.
