===============
Odoo essentials
===============

.. toctree::

   essentials/stages
   essentials/activities
   essentials/reporting
   essentials/search
   essentials/html_editor
   essentials/contacts
   essentials/export_import_data
   essentials/in_app_purchase
   essentials/keyboard_shortcuts
   essentials/property_fields
   essentials/product_catalog
