:show-content:

=====
Users
=====

Odoo defines a *user* as someone who has access to a database. An administrator can add as many
users as the company needs and, in order to restrict the type of information each user can access,
rules can be applied to each user. Users and access rights can be added and changed at any point.

.. seealso::
   - :doc:`users/language`
   - :doc:`users/access_rights`
   - :ref:`access-rights/superuser`
   - :ref:`access-rights/groups`

.. _users/add-individual:

Add individual users
====================

To add new users, navigate to :menuselection:`Settings app --> Users section --> Manage Users`, and
click on :guilabel:`New`.

.. image:: users/manage-users.png
   :alt: View of the settings page emphasizing the manage users field in Odoo.

Fill in the form with all the required information. Under the :doc:`Access Rights
<users/access_rights>` tab, choose the group within each application the user can have access to.

The list of applications shown is based on the applications installed on the database.

.. image:: users/new-user.png
   :alt: View of a user's form emphasizing the access rights tab in Odoo.

After filling out all the necessary fields on the page, :icon:`fa-cloud-upload` :guilabel:`(Save
manually)`. An invitation email is automatically sent to the user, using the email in the
:guilabel:`Email Address` field. The user must click on the link included in the email to accept the
invitation, and to create a database login.

.. image:: users/invitation-email.png
   :alt: View of a user's form with a notification that the invitation email has been sent in Odoo.

.. warning::
   If the company is on a monthly subscription plan, the database automatically updates to reflect
   the added users. If the company is on a yearly or multi-year plan, an expiration banner appears
   in the database. An upsell quotation can be created by clicking the banner to update the
   subscription. Alternatively, `send a support ticket <https://www.odoo.com/help>`_ to resolve the
   issue.

User type
---------

:guilabel:`User Type` can be chosen on the :guilabel:`Manage Users` page by clicking on the search
bar, and then :ref:`setting a filter <search/preconfigured-filters>` for either :guilabel:`Internal
User` or :guilabel:`Portal User`.

Odoo databases have three types of users: :guilabel:`Internal User`, :guilabel:`Portal`, and
:guilabel:`Public`. Users are considered *internal database* users. Portal users are *external
users*, who only have access to the database portal to view records. Public users are those visiting
websites, via the website's frontend. See the documentation on :doc:`users/user_portals`.

The :guilabel:`Portal` user option does **not** allow the administrator to choose access rights.
These users have specific access rights pre-set (such as, record rules and restricted menus), and
usually do not belong to the usual Odoo groups.

User devices
============

For security purposes, when a user logs into the database, the various login information, such as
the IP address, is stored in the user's profile. It is best practice to check this periodically, to
ensure all access is from the user, and no one else has accessed the database.

To check the logged-in devices, click the user icon in the upper-right corner, and click
:guilabel:`My Preferences` to open the user's profile. Click the *Security* tab to view a
list of all devices the user has logged into the database with. Any device currently logged into the
system displays a green circle next to the device name on the Kanban card.

.. image:: users/devices.png
   :alt: The Kanban view of all user devices.

Revoke devices
--------------

If a listed device is **not** a legitimate user device and could be a potential security risk,
remove the device and revoke access by clicking the :guilabel:`Log out` button.

An :guilabel:`Access Control` pop-up window loads, requesting the user to confirm their identity.
Enter the user's password, then click :guilabel:`Confirm Password`.

The device disappears from the *Security* tab and can no longer be used to log into the database.

.. image:: users/security.png
   :alt: The security pop-up window asking to verify the account with a password.

.. _users/deactivate:

Deactivate users
================

To deactivate (i.e. archive) a user, navigate to :menuselection:`Settings app --> Users section -->
Manage Users`. Then, tick the checkbox to the left of the users to be deactivated.

After selecting the appropriate user to be archived, click the :icon:`fa-cog` :guilabel:`(Actions)`
icon, and select :guilabel:`Archive` from the resulting drop-down menu. Then, click :guilabel:`OK`
from the :guilabel:`Confirmation` pop-up window that appears.

Error: too many users
---------------------

If there are more users in an Odoo database than provisioned in the Odoo Enterprise subscription,
the following message is displayed.

.. image:: users/add-more-users.png
   :alt: Too many users on a database error message.

When the message appears, the database administrator has 30 days to act before the database expires.
The countdown is updated every day.

To resolve the issue, either:

- Add more users to the subscription by clicking the :guilabel:`Upgrade your subscription` link
  displayed in the message to validate the upsell quotation, and pay for the extra users.
- :ref:`Deactivate users <users/deactivate>`, and reject the upsell quotation.

.. warning::
   If the company is on a monthly subscription plan, the database automatically updates to reflect
   the added users. If the company is on a yearly or multi-year plan, an expiration banner appears
   in the database. An upsell quotation can be created by clicking the banner to update the
   subscription. Alternatively, users can `send a support ticket <https://www.odoo.com/help>`_ to
   resolve the issue.

Once the database has the correct number of users, the expiration message disappears automatically
after a few days, when the next verification occurs.

.. _users/passwords-management:

Password management
===================

Password management is an important part of granting users autonomous access to the database at all
times. Odoo offers a few different methods to reset a user's password.

.. tip::
   To enforce a minimum password length requirement, :ref:`install <general/install>` the
   :guilabel:`Password Policy` (`auth_password_policy`) module. Then, open the :guilabel:`Settings`
   app, navigate to the *Permissions* section, and enter the desired password length in the
   :guilabel:`Minimum Password Length` field. By default, the value is `8`.

.. _users/reset-password:

Reset password
--------------

Sometimes, users might wish to reset their personal password for added security, so they are the
only ones with access to the password. Odoo offers two different reset options: one initiated by the
user to reset the password, and another where the administrator triggers a reset.

.. _users/reset-password-login:

Enable password reset from login page
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

It is possible to enable/disable password resets directly from the login page. This action is
completed by the individual user, and this setting is enabled by default.

To change this setting, go to :menuselection:`Settings app --> Permissions` section, activate
:guilabel:`Password Reset`, and then click :guilabel:`Save`.

.. image:: users/password-reset-login.png
   :alt: Enabling Password Reset in Odoo Settings.

On the login page, click :guilabel:`Reset Password` to initiate the password reset process, and have
a reset-token sent to the email on file.

.. _users/reset-password-email:

Send reset instructions
~~~~~~~~~~~~~~~~~~~~~~~

Go to :menuselection:`Settings app --> Users & Companies --> Users`, select the user from the list,
and click on :guilabel:`Send Password Reset Instructions` on the user form. An email is
automatically sent to them with password reset instructions.

.. note::
   The :guilabel:`Send Password Reset Instructions` button **only** appears if the Odoo invitation
   email has already been confirmed by the user. Otherwise, a :guilabel:`Re-send Invitation Email`
   button appears.

This email contains all the instructions needed to reset the password, along with a link redirecting
the user to an Odoo login page.

.. image:: users/password-reset-email.png
   :alt: Example of an email with a password reset link for an Odoo account.

.. _users/change-password:

Change user password
--------------------

Go to :menuselection:`Settings app --> Users & Companies --> Users`, and select a user to access its
form. Click on the :icon:`fa-cog` :guilabel:`(Actions)` icon, and select :guilabel:`Change Password`
from the resulting drop-down menu. Enter a new password in the :guilabel:`New Password` column of
the :guilabel:`Change Password` pop-up window that appears, and confirm the change by clicking
:guilabel:`Change Password`.

.. image:: users/change-password.png
   :alt: Change a user's password on Odoo.

.. note::
   This operation only modifies the password of the users locally, and does **not** affect their
   Odoo account.

   If the Odoo password needs to be changed, use the :ref:`send the password reset
   <users/reset-password-email>`. Odoo.com passwords grant access to the *My Databases* page, and
   other portal features.

After clicking :guilabel:`Change Password`, the page is redirected to an Odoo login page where the
database can be re-accessed using the new password.

.. _users/multi-companies:

Multi companies
===============

The :guilabel:`Companies` field on a user form determines which companies a user can access. To
configure multi-company access, navigate to :menuselection:`Settings app --> Users section -->
Manage Users`. Then select the desired user to open their user form.

In the *Access Rights* tab, under the *Roles* section, configure the :guilabel:`Companies` and
:guilabel:`Default Company` fields:

- :guilabel:`Companies`: Select one or more companies the user can access. The user's access and
  editing permissions are determined by their assigned access rights.
- :guilabel:`Default Company`: Select the company that is automatically selected when the user logs
  in. Only one company can be set as the default.

.. warning::
   Incorrectly configuring multi-company access can result in inconsistent behavior across
   companies. Only experienced Odoo users should modify user access rights in databases with a
   multi-company configuration. For technical explanations, refer to the developer documentation on
   :doc:`../../../developer/howtos/company`.

.. image:: users/multi-companies.png
   :alt: View of a user's form emphasizing the multi companies field in Odoo.

.. seealso::
   :doc:`companies`

.. toctree::
   :titlesonly:

   users/language
   users/2fa
   users/access_rights
   users/user_portals
   users/facebook
   users/google
   users/azure
   users/ldap
