=============================
Standard and extended support
=============================

.. warning::
   The information presented on this page is not intended to amend, modify, or replace any terms of
   the :doc:`Odoo Enterprise Subscription Agreement <../legal/terms/enterprise>`. In the event of
   any inconsistency or conflict, the Subscription Agreement shall govern.

Odoo provides **standard support** for all major versions for three years. It includes helpdesk
support, bug fixing, and security updates.

Beyond those three years, **extended support** is subject to a mandatory additional fee and includes
helpdesk support and bug fixes (depending on feasibility).

.. note::
   - Odoo releases intermediary versions, called online or SaaS versions, every two to three months.
     These versions are only available on Odoo Online and are not eligible for extended support.
   - You can `upgrade <https://upgrade.odoo.com>`_ from any version **to supported versions** only.
     The last unsupported version can still be used as an upgrade target for up to six months
     following its end-of-life date.

The table below shows the support status of every version. Major releases are highlighted in bold.

.. list-table::
   :header-rows: 1
   :widths: auto

   * -
     - Odoo Online
     - Odoo.sh
     - On-premise
     - Release date
     - End of standard support
   * - Odoo SaaS 19.4
     - |green|
     - N/A
     - N/A
     - July 2026
     -
   * - Odoo SaaS 19.3
     - |green|
     - N/A
     - N/A
     - May 2026
     -
   * - Odoo SaaS 19.2
     - |green|
     - N/A
     - N/A
     - March 2026
     -
   * - Odoo SaaS 19.1
     - |red|
     - N/A
     - N/A
     - January 2026
     -
   * - **Odoo 19.0**
     - |green|
     - |green|
     - |green|
     - September 2025
     - September 2028 (planned)
   * - Odoo SaaS 18.4
     - |red|
     - N/A
     - N/A
     - July 2025
     -
   * - Odoo SaaS 18.3
     - |red|
     - N/A
     - N/A
     - May 2025
     -
   * - Odoo SaaS 18.2
     - |red|
     - N/A
     - N/A
     - March 2025
     -
   * - **Odoo 18.0**
     - |green|
     - |green|
     - |green|
     - October 2024
     - September 2027 (planned)
   * - **Odoo 17.0**
     - |green|
     - |green|
     - |green|
     - November 2023
     - September 2026 (planned)
   * - **Odoo 16.0**
     - |red|
     - |orange|
     - |orange|
     - October 2022
     - September 2025
   * - **Odoo 15.0**
     - |red|
     - |orange|
     - |orange|
     - October 2021
     - October 2024
   * - **Odoo 14.0**
     - |red|
     - |orange|
     - |orange|
     - Before 2021
     - Before 2024
   * - Older versions
     - |red|
     - |red|
     - |orange|
     - Before 2021
     - Before 2024

.. admonition:: Legend

   |green| : Standard support

   |orange| : Extended support (mandatory extra fee)

   |red| : Not supported

   N/A : Never released for this platform

.. |green| raw:: html

   <span class="text-success" style="font-size: 32px; line-height: 32px; display: inline-block; vertical-align: middle;">●</span>

.. |orange| raw:: html

   <span class="text-warning" style="font-size: 32px; line-height: 32px; display: inline-block; vertical-align: middle;">●</span>

.. |red| raw:: html

   <span class="text-danger" style="font-size: 32px; line-height: 32px; display: inline-block; vertical-align: middle;">●</span>
